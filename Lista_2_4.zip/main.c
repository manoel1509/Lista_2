#include <stdio.h>
#include <unistd.h>

int main(void) {
  
int chave_pisca, chave_geral;

printf ("Pisca desligado\n");

printf ("Chave geral > 0-Desligada; 1-Ligada: ");
scanf ("%d", &chave_geral);

  while (chave_geral == 1) {
    printf ("Pisca > 0-Desligada; 1-Ligada: ");
    scanf ("%d", &chave_pisca);

    if (chave_pisca == 1) {
    printf ("Pisca ligado.\n");
    sleep(2);
    printf ("Pisca desligado.\n");
    sleep(2);
    printf ("Pisca ligado.\n");
    sleep(2);
    printf ("Pisca desligado.\n");
    sleep(2);
    printf ("Pisca ligado.\n");
    sleep(2);
    printf ("Pisca desligado.\n");
    sleep(2);
  }
}
  printf ("Pisca desligado\n");

  return 0;
}