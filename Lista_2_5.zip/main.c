#include <stdio.h>
#include <math.h>
#include <unistd.h>

int main(void) {

int valor_temp, valor_vent;

printf ("Veitoinha desligada.\n");

printf ("Digite o valor da temperatura do radiador: \n"); 
scanf ("%d", &valor_temp);

if (valor_temp >= 90) {
  printf ("Ventoinha ligada.\n");

  while (valor_temp > 70) {
    valor_temp = valor_temp - 1;
    printf ("A temperatura do radiador é: %d \n", valor_temp);
    printf ("Ventoinha ligada.\n");
    sleep (1);
  }
  printf ("A temperatura do radiador é: %d \n", valor_temp);
  printf ("Veitoinha desligada. \n");
}
else {
  printf ("Veitoinha desligada. \n");
  printf ("A temperatura do radiador é: %d \n", valor_temp);
}
 return 0;
}